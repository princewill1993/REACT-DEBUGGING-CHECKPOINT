# REACT DEBUGGING

### Fixed the error relating to react strict mode

### Fixed the error for props Types

### Fixed the error for Hook side effects
